sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"jquery.sap.global",
	"sap/viz/ui5/api/env/Format"
], function (Controller, JSONModel, jQuery, formatter) {
	"use strict";

	return Controller.extend("MTech_Project.ext.controller.Sentiment", {
		formatter: formatter,
		onInit: function () {

		},
		onCalculate: function () {
			var _this = this;
			//			var qid ='ID_FA163EE56C3A1ED88C96B6B4789140DE';
			var questid = this.getView().getBindingContext().getProperty('questid');
			var oModel = new sap.ui.model.odata.ODataModel(
				"https://webidetesting8467139-fiori.dispatcher.int.sap.hana.ondemand.com/sap/opu/odata/sap/ZC_MT_VIEW1_CDS/ZC_MT_View1('"+questid+"')/to_view2",
				true);

			oModel.read("/", {
				success: function (oData) {
					$.ajax({
						type: "POST",
						url: "http://127.0.0.1:8081/sentiment",
						contentType: "application/json",
						data: JSON.stringify(oData.results),
						dataType: "json",
						success: function (response) {
							//console.log(response);
							var p_result = JSON.parse(response);

							var pos = 0,
								neg = 0,
								i = 0;
							for (i = 0; i < p_result.length; i++) {
								if (p_result[i].polarity === "1") {
									pos++;
									p_result[i].polarity = "Positive";
								} else {
									neg++;
									p_result[i].polarity = "Negative";
								}
							}
							_this.fillPieChart(pos, neg);
							_this.fillSentimentDataTable(p_result);
						},
						error: function (err) {
							console.log(err);
						}
					});

					//console.log(oData); 
				},
				error: function (oError) {}
			});
		},

		fillPieChart: function (pos, neg) {
			//Start of pie 
			var oPie = this.getView().byId("idDonutChart");
			var oModel_pie = new JSONModel();
			var oData_pie = [{
				"Feedback": "POSITIVE",
				"Value": pos
			}, {
				"Feedback": "NEGATIVE",
				"Value": neg
			}];
			oModel_pie.setData(oData_pie);
			oPie.setModel(oModel_pie);

		},

		fillSentimentDataTable: function (oData) {
			var oTable = this.getView().byId("idTable");
			var oModel = new JSONModel();
			oModel.setData(oData);
			oTable.setModel(oModel);

		}
	});

});