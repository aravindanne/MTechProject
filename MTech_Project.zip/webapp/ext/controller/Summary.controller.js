sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"jquery.sap.global",
	"sap/viz/ui5/api/env/Format"
], function (Controller, JSONModel, jQuery, formatter) {
	"use strict";

	return Controller.extend("MTech_Project.ext.controller.Summary", {
		formatter: formatter,
		onInit: function () {

		},
		onDetect: function () {
			var _this = this;
			//			var qid ='ID_FA163EE56C3A1ED88C96B6B4789140DE';
			var questid = this.getView().getBindingContext().getProperty('questid');
			var oModel = new sap.ui.model.odata.ODataModel(
				"https://webidetesting8467139-fiori.dispatcher.int.sap.hana.ondemand.com/sap/opu/odata/sap/ZC_MT_VIEW1_CDS/ZC_MT_View1('"+questid+"')/to_view2",
				true);

			oModel.read("/", {
				success: function (oData) {
					//Call the Topic API
					$.ajax({
						type: "POST",
						url: "http://127.0.0.1:8081/detectTopic",
						contentType: "application/json",
						data: JSON.stringify(oData.results),
						dataType: "json",
						success: function (response) {
							//console.log(response);
							var p_result = JSON.parse(response);
							//Start of pie 
							var oPie = _this.getView().byId("idTopicDonut");
							var oModel_pie = new JSONModel();
							var oData_pie = p_result;
							oModel_pie.setData(oData_pie);
							oPie.setModel(oModel_pie);

							/**** Start of Cluster REST API ****/
							$.ajax({
								type: "POST",
								url: "http://127.0.0.1:8081/generateCluster",
								contentType: "application/json",
								data: JSON.stringify(p_result),
								dataType: "json",
								success: function (resp) {
									//console.log(response);
									var cluster_data = JSON.parse(resp);
									//Start of pie 
									var c_oPie = _this.getView().byId("idClusterDonut");
									var c_oModel_pie = new JSONModel();
									var c_oData_pie = cluster_data;
									c_oModel_pie.setData(c_oData_pie);
									c_oPie.setModel(c_oModel_pie);
								},
								error: function (err) {
									console.log(err);
								}
							});

							/**** End of Cluster REST API *****/

						},
						error: function (err) {
							console.log(err);
						}
					});

					//Call the cluster API
					//console.log(oData); 
				},
				error: function (oError) {}
			});
		},
		myOnClickHandler: function(oEvent){
		//	alert(oEvent.getParameter('data')[0].data.Name);
			var data = oEvent.getParameter('data')[0].data;
			$.ajax({
								type: "POST",
								url: "http://127.0.0.1:8081/summary",
								contentType: "application/json",
								data: JSON.stringify([data]),
								dataType: "json",
								success: function (resp) {
									//console.log(response);
									var result = JSON.stringify(resp);
									//Start of pie 
									sap.m.MessageBox.success("Text: "+result, {});
								},
								error: function (err) {
									console.log(err);
								}
							});
							
							
		
		}

	});

});