jQuery.sap.declare("MTech_Project.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
jQuery.sap.require("sap.ui.generic.app.AppComponent");

sap.ui.generic.app.AppComponent.extend("MTech_Project.Component", {
	metadata: {
		"manifest": "json"
	}
});